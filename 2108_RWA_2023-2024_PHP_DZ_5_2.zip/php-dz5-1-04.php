<!DOCTYPE html>
<html>
<head>
    <title>DZ 2</title>
</head>
<body>

<?php

function faktorijel($broj) {
    $rezultat = 1;
    echo "Faktorijel broja $broj je: ";
    for ($i = 1; $i <= $broj; $i++) {
        $rezultat *= $i;
        echo "$i";
        if ($i < $broj) {
            echo " * ";
        }
    }
    echo " = $rezultat<br>";
}

faktorijel(5);
faktorijel(7);
faktorijel(18);

?>

</body>
</html>
