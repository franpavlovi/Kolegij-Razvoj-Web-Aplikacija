<!DOCTYPE html>
<html>
<head>
    <title>DZ 2</title>
</head>
<body>

<?php

function promijeniCase($polje, $oblik) {
    $rezultat = array();
    
    foreach ($polje as $kljuc => $vrijednost) {
        if ($oblik == 'UPPER') {
            $rezultat[$kljuc] = strtoupper($vrijednost);
        } elseif ($oblik == 'LOWER') {
            $rezultat[$kljuc] = strtolower($vrijednost);
        }
    }
    
    return $rezultat;
}

// Primjer ulaznog polja
$boje = array('B' => 'Blue', 'G' => 'Green', 'r' => 'Red');


echo "Vrijednosti u lowercase.<pre>";
print_r(promijeniCase($boje, 'LOWER'));
echo "</pre>";

echo "Vrijednosti u uppercase.<pre>";
print_r(promijeniCase($boje, 'UPPER'));
echo "</pre>";

?>

</body>
</html>
