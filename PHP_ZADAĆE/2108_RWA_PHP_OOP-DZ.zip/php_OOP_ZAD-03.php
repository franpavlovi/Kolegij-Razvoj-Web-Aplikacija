<!DOCTYPE html>
<html>
<head>
 
</head>
<body>

<?php

class Person {
    public $ime;
    public $prezime;
    public $masa_kg;

    public function __construct($ime, $prezime, $masa_kg) {
        $this->ime = $ime;
        $this->prezime = $prezime;
        $this->masa_kg = $masa_kg;
    }

    public function izracunajTezinu() {
        return $this->masa_kg;
    }

    public function izracunajTezinuNaMjesecu() {
        
        $omjer_mase_mjesec_zemlja = 0.166;

        return $this->masa_kg * $omjer_mase_mjesec_zemlja;
    }
}


$osoba1 = new Person("JN", "NNN", 70);
$osoba2 = new Person("JZZ", "QQQ", 65);


echo "Osoba 1: " . $osoba1->ime . " " . $osoba1->prezime . " - Težina na Zemlji: " . $osoba1->izracunajTezinu() . " kg, Težina na Mjesecu: " . $osoba1->izracunajTezinuNaMjesecu() . " kg<br>";
echo "Osoba 2: " . $osoba2->ime . " " . $osoba2->prezime . " - Težina na Zemlji: " . $osoba2->izracunajTezinu() . " kg, Težina na Mjesecu: " . $osoba2->izracunajTezinuNaMjesecu() . " kg<br>";


?>

</body>
</html>