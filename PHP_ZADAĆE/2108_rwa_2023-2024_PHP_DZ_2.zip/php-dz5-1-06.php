<!DOCTYPE html>
<html>
<head>
    <title>DZ 2</title>
</head>
<body>

<?php

function temperaturaStatistika($temperaturaString) {
    
    $temperature = explode(", ", $temperaturaString);
    
    $prosjek = array_sum($temperature) / count($temperature);
    

    sort($temperature);
    
    $najnize = array_slice($temperature, 0, 10);
    
    $najvise = array_slice($temperature, -10);


    echo "Prosječna temperatura: " . number_format($prosjek, 2) . " °C<br>";
    echo "Deset najnižih temperatura: " . implode(", ", $najnize) . " °C<br>";
    echo "Deset najviših temperatura: " . implode(", ", $najvise) . " °C<br>";
}

$temperatureString = "78, 60, 62, 68, 71, 68, 73, 85, 66, 64, 76, 63, 81, 76, 73, 68, 72, 73, 75, 65, 74, 63, 67, 65, 64, 68, 73, 75, 79, 73";

temperaturaStatistika($temperatureString);

?>

</body>
</html>
