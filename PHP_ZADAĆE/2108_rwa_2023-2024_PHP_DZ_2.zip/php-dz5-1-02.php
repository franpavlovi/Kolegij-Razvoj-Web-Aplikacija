<!DOCTYPE html>
<html>
<head>
    <title>DZ 2</title>
</head>
<body>

<?php

function aritmetickaSredina($broj1, $broj2) {
    $sredina = ($broj1 + $broj2) / 2;
    echo "Aritmetička sredina između $broj1 i $broj2 je: $sredina<br>";
}

aritmetickaSredina(5, 10);
aritmetickaSredina(20, 30);
aritmetickaSredina(8, 12);

?>

</body>
</html>
