<!DOCTYPE html>
<html>
<head>
    <title>DZ 2</title>
</head>
<body>

<?php

function aritmetickaGeometrijskaSredina($skup) {
    $brojevi = explode(",", $skup);
    
    $aritmetickaSredina = array_sum($brojevi) / count($brojevi);
    
    $geometrijskaSredina = pow(array_product($brojevi), 1 / count($brojevi));

    echo "Aritmetička sredina: $aritmetickaSredina<br>";
    echo "Geometrijska sredina: $geometrijskaSredina<br>";
}

$skup1 = "1,3,6,7,8,4,4,16,18,14,19";
aritmetickaGeometrijskaSredina($skup1);

?>

</body>
</html>
