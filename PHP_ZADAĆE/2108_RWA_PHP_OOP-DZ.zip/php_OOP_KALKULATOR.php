<!DOCTYPE html>
<html>
<head>
    <title>KALKULATOR
    </title>
</head>
<body>

<?php

class Kalkulator {
    private $rezultat;

    public function __construct() {
        $this->rezultat = 0;
    }

    public function zbroji($broj) {
        $this->rezultat += $broj;
    }

    public function oduzmi($broj) {
        $this->rezultat -= $broj;
    }

    public function pomnozi($broj) {
        $this->rezultat *= $broj;
    }

    public function podijeli($broj) {
        if ($broj != 0) {
            $this->rezultat /= $broj;
        }
    }

    public function getRezultat() {
        return $this->rezultat;
    }
}


$kalkulator = new Kalkulator();

$kalkulator->zbroji(5);
echo "Rezultat nakon zbrajanja 5: " . $kalkulator->getRezultat() . "<br>";

$kalkulator->oduzmi(3);
echo "Rezultat nakon oduzimanja 3: " . $kalkulator->getRezultat() . "<br>";

$kalkulator->pomnozi(4);
echo "Rezultat nakon množenja s 4: " . $kalkulator->getRezultat() . "<br>";

$kalkulator->podijeli(2);
echo "Rezultat nakon dijeljenja s 2: " . $kalkulator->getRezultat() . "<br>";

?>
</body>
</html>