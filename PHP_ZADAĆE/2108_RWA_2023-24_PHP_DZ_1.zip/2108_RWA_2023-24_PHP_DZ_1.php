<!DOCTYPE html>
<html>
<head>
    <title>FRAN PAVLOVIĆ DZ 1</title>
</head>
<body>

<?php

// Zadatak 1 - ispis brojeva od 1 do 20 i njihovih kvadrata
echo "Zadatak 1 - rješenje: <br>";
for ($i = 1; $i <= 20; $i++) {
    $kvadrat = $i * $i;
    echo "$i: $kvadrat <br>";
}

// Zadatak 2 - suma prvih 100 prirodnih brojeva korištenjem for petlje
echo "<br>Zadatak 2 - rješenje: <br>";
$suma = 0;
for ($i = 1; $i <= 100; $i++) {
    $suma += $i;
}
echo "Suma prvih 100 prirodnih brojeva: $suma <br>";

// Zadatak 3 - suma prvih 100 prirodnih brojeva korištenjem while petlje
echo "<br>Zadatak 3 - rješenje: <br>";
$suma = 0;
$i = 1;
while ($i <= 100) {
    $suma += $i;
    $i++;
}
echo "Suma prvih 100 prirodnih brojeva (while petlja): $suma <br>";

// Zadatak 4 - ispis svih parnih brojeva od 1 do 100 u novim retcima
echo "<br>Zadatak 4 - rješenje: <br>";
for ($i = 1; $i <= 100; $i++) {
    if ($i % 2 == 0) {
        echo "$i <br>";
    }
}

// Zadatak 5 - ispis svih troznamenkastih parnih brojeva
echo "<br>Zadatak 5 - rješenje: <br>";
for ($i = 100; $i <= 999; $i += 2) {
    echo "$i <br>";
}

// Zadatak 6 - ispis brojeva koji se mogu podijeliti pomoći 3 i 5 
echo "<br>Zadatak 6 - rješenje: <br>";
for ($i = 10; $i < 100; $i++) {
    if ($i % 3 == 0 && $i % 5 == 0) {
        echo "Broj $i je dijeljiv sa 3 i 5 <br>";
    }
    else if ($i % 3 == 0) {
        echo "Broj $i je dijeljiv sa 3 <br>";
    }
    else if ($i % 5 == 0) {
        echo "Broj $i je dijeljiv sa 5 <br>";
    }
}

// Zadatak 7 - računanje prosjeka stanovnika kroz godine te ispis godine sa najvećim brojem statnovnika
echo "<br>Zadatak 7 - rješenje: <br>";   
$grad = array(1995 => 25555, 1998 => 33000, 1998 => 33310, 2000 => 37877, 2002 => 45000);

$prosjek = array_sum($grad) / count($grad);
echo "a) Prosječan broj stanovnika kroz sve godine: $prosjek <br>";

$max_stanovnika = max($grad);
$max_godina = array_search($max_stanovnika, $grad);
echo "b) Godina s najviše stanovnika: $max_godina (stanovnika: $max_stanovnika) <br>";

$broj_godina = count($grad);
echo "c) Koliko godina se provodilo mjerenje: $broj_godina <br>";

// Zadatak 8 - ispis prostih brojeva manjih od 100
echo "<br>Zadatak 8 - rješenje: <br>";
function prost($broj) {
    if ($broj <= 1) {
        return false;
    }
    for ($i = 2; $i < $broj; $i++) {
        if ($broj % $i === 0) {
            return false;
        }
    }
    return true;
}

echo "Prosti brojevi manji od 100 su: <br>";

for ($i = 2; $i < 100; $i++) {
    if (prost($i)) {
        echo $i . " ";
    }
}

// Zadatak 9 - zbrajanje pomoću foreach petlje
echo "<br><br>Zadatak 9 - rješenje: <br>";
$brojevi = array(1, 22, 3, 4, 5, 55, 12, 49, 94, 23, 7);
$zbroj = 0;

foreach ($brojevi as $broj) {
    $zbroj += $broj;
}

echo "Zbroj članova polja: $zbroj <br>";

// Zadatak 10 - računanje površine pravokutnika
echo "<br>Zadatak 10 - rješenje: <br>";
$a = 5; 
$b = 8; 
$povrsina_pravokutnika = $a * $b;

echo "Površina pravokutnika širine $a i dužine $b iznosi $povrsina_pravokutnika <br>";

?>



</body>
</html>